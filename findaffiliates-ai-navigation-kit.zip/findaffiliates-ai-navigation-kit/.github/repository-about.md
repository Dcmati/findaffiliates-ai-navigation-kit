# Suggested GitHub repository settings

## Repository name

```text
findaffiliates-ai-navigation-kit
```

## Description

```text
Public AI-readable documentation for navigating FindAffiliates.online and extracting affiliate program data from Markdown-friendly pages, llms.txt, sitemap URLs, API catalog, and Agent Skills.
```

## Website

```text
https://www.findaffiliates.online/
```

## Topics

```text
affiliate-marketing
affiliate-programs
ai-agents
llms-txt
markdown
sitemap
robots-txt
agent-skills
webmcp
data-extraction
seo
```

## Visibility

Public

## Recommended first commit message

```text
Initial AI navigation kit for FindAffiliates
```
